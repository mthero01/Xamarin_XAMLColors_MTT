﻿/** [!]. ABOUT
 * "Color Picker"
 * by Matthew T. Theroux
 * for Baker College Online CS4010 
 * Module 06 Assignment 01 (#11)
 * under Joan Zito
 * -picks a color using XAML
**/

/// [I]. HEAD
///  A] IMPORTS
using System;
using Xamarin.Forms;

/// <summary> </summary>
namespace ColorPicker
{

    ///
    [TypeConverter(typeof(LayoutOptionsConverter))]
    public struct LayoutOptions
    {

    }// /cnvtr 'LayoutOptions'

    ///
    [TypeConverter(typeof(ColorTypeConverter))]
    public struct Color
    {

    }// /cnvtr 'Color'

    ///
    public class Label : View, IFontElement
    {
        /// <summary> </summary>
        [TypeConverter(typeof(FontSizeConverter))]
        public double FontSize
        {

        }
    }// /cla 'Label'

    /// 
    [Flags]
    public enum FontAttributes
    {
        None = 0,
        Bold = 1,
        Italic = 2
    }// /flags 'FontAttributes'


    /// <summary> The main action </summary>
    public class ColorPicker
    {

        /// Constructors
        /// 0.
        public ColorPicker()
        {
            new Frame
            {
                OutlineColor = Color.Accent,
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = VerticalOptions.Center,
                Content = new Label
                {
                    Text = "Greetings, from Xamarin.Forms"
                }// /lbl (Content)
            };// /fra (window)
        }// /cxtr (default)

        ///  3.
        public ColorPicker(Color col1, Color col2, Color col3)
        {
            // <...>
        }// /cxtr (3 colors)

    }// /cla 'ColorPicker'
}// /ns 'ColorPicker'
 /// [EoF].